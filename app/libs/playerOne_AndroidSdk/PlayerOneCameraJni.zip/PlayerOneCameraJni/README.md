# Player One Camera JNI SDK

This project wraps the Player One Camera C SDK from `PlayerOneCamera.h` for Android.
The supplied native binaries are currently packaged for `arm64-v8a`.

## Build

Set `sdk.dir` in `local.properties` to the Android SDK directory, then run:

```text
gradlew.bat :camera-sdk:assembleRelease
```

The AAR is written to `camera-sdk/build/outputs/aar/camera-sdk-release.aar`.
The Java-only classes JAR is written to `camera-sdk/build/intermediates/aar_main_jar/release/syncReleaseLibJars/classes.jar`.

## Consumer usage

```java
import com.playerone.camera.POACameraProperties;
import com.playerone.camera.PlayerOneCamera;

int count = PlayerOneCamera.getCameraCount();
POACameraProperties camera = new POACameraProperties();
int error = PlayerOneCamera.getCameraProperties(0, camera);
if (error == PlayerOneCamera.POA_OK) {
    PlayerOneCamera.openCamera(camera.cameraID);
    PlayerOneCamera.initCamera(camera.cameraID);
}
```

If the consuming application also includes OpenCV or another native library
that packages `libc++_shared.so`, keep one copy during APK packaging:

```groovy
android {
    packaging {
        jniLibs {
            pickFirsts += ["**/libc++_shared.so"]
        }
    }
}
```

The native methods return the original `POAErrors` value. For image capture, call
`getImageSize`, `getImageFormat`, `startExposure`, `imageReady`, and then
`getImageData` with a buffer large enough for the selected format. The
`readImageData` helper is available when only a byte array result is needed.

## Native dependency

The AAR includes `libPlayerOneCamera.so` and `libusb-1.0.so` under
`arm64-v8a`. Devices using another ABI need a matching vendor SDK binary
before adding that ABI to the Gradle configuration.

The `libPlayerOneCamera.so` packaged here is the Android-compatible copy from
the existing Android project. The separate `D:\file\libPlayerOneCamera.so`
was inspected but not packaged because it links against Linux glibc libraries
(`libc.so.6`, `libstdc++.so.6`) and cannot be loaded by Android.

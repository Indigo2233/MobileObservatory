package com.playerone.sample;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import com.playeroneastronomy.camera.CameraProperties;
import com.playeroneastronomy.camera.ConfigAttributes;
import com.playeroneastronomy.camera.ConfigResult;
import com.playeroneastronomy.camera.ConfigValue;
import com.playeroneastronomy.camera.GainOffsetPreset;
import com.playeroneastronomy.camera.ImagePosition;
import com.playeroneastronomy.camera.ImageSize;
import com.playeroneastronomy.camera.LegacyGainOffset;
import com.playeroneastronomy.camera.PlayerOneCamera;
import com.playeroneastronomy.camera.PlayerOneCameraSdk;
import com.playeroneastronomy.camera.PlayerOneUsbManager;
import com.playeroneastronomy.camera.PoaBayerPattern;
import com.playeroneastronomy.camera.PoaCameraState;
import com.playeroneastronomy.camera.PoaConfig;
import com.playeroneastronomy.camera.PoaError;
import com.playeroneastronomy.camera.PoaException;
import com.playeroneastronomy.camera.PoaImageFormat;
import com.playeroneastronomy.camera.PoaValueType;
import com.playeroneastronomy.camera.SensorModeInfo;
import com.playeroneastronomy.camera.UsbCameraDevice;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A field test console for every public API documented by the SDK. */
public final class MainActivity extends Activity {
    private static final int INK = Color.rgb(24, 33, 43);
    private static final int MUTED = Color.rgb(91, 102, 114);
    private static final int BLUE = Color.rgb(21, 95, 154);
    private static final int PANEL = Color.WHITE;
    private static final int PAGE = Color.rgb(245, 247, 248);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private LinearLayout content;
    private TextView sdkStatus;
    private TextView usbStatus;
    private TextView cameraStatus;
    private TextView configStatus;
    private TextView imageStatus;
    private TextView sensorStatus;
    private TextView gainStatus;
    private TextView coolerStatus;
    private TextView logView;
    private ImageView imagePreview;

    private Spinner deviceSpinner;
    private Spinner cameraSpinner;
    private Spinner configSpinner;
    private Spinner formatSpinner;
    private Spinner sensorSpinner;
    private ArrayAdapter<String> deviceAdapter;
    private ArrayAdapter<String> cameraAdapter;
    private ArrayAdapter<String> configAdapter;
    private ArrayAdapter<String> formatAdapter;
    private ArrayAdapter<String> sensorAdapter;

    private EditText configValueInput;
    private CheckBox configAutoInput;
    private EditText roiXInput;
    private EditText roiYInput;
    private EditText roiWidthInput;
    private EditText roiHeightInput;
    private EditText binInput;
    private EditText timeoutInput;
    private EditText customIdInput;
    private EditText gainInput;
    private CheckBox coolerInput;
    private CheckBox fullResolutionPreviewInput;

    private PlayerOneUsbManager usbManager;
    private List<UsbCameraDevice> usbDevices = Collections.emptyList();
    private List<PlayerOneCamera> cameras = Collections.emptyList();
    private PlayerOneCamera currentCamera;
    private ConfigAttributes currentConfigAttributes;
    private List<SensorModeInfo> sensorModes = Collections.emptyList();
    private volatile boolean continuousRunning;
    private boolean openCvReady;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        openCvReady = OpenCVLoader.initLocal();
        appendLog("OpenCV 初始化: " + (openCvReady ? "成功" : "失败，使用灰度回退"));
        createUsbManager();
        refreshUsbDevices();
        refreshSdkOverview();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(PAGE);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(32));
        scroll.addView(content, new ViewGroup.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView title = text("Player One Camera SDK 测试台", 24, INK, true);
        content.addView(title, widthWrap());
        TextView subtitle = text("按 PLAYERONE_CAMERA_SDK_API.html 覆盖公开 Java API。相机操作需连接并授权 Player One USB 设备。", 13, MUTED, false);
        subtitle.setPadding(0, dp(6), 0, dp(14));
        content.addView(subtitle, widthWrap());

        buildSdkSection();
        buildUsbSection();
        buildCameraSection();
        buildConfigSection();
        buildImageSection();
        buildSensorSection();
        buildGainSection();
        buildCoolingSection();
        buildLogSection();
    }

    private void buildSdkSection() {
        LinearLayout panel = section("SDK 概览", "PlayerOneCameraSdk 静态接口和错误码");
        sdkStatus = valueText("未查询");
        panel.addView(sdkStatus, widthWrap());
        panel.addView(row(
                button("刷新 SDK 信息", v -> refreshSdkOverview()),
                button("显示全部错误码", v -> showAllErrors())
        ), widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildUsbSection() {
        LinearLayout panel = section("USB 设备与权限", "refreshDevices / requestPermission / runSingleFrameDiagnostic");
        deviceSpinner = spinner();
        deviceAdapter = adapter();
        deviceSpinner.setAdapter(deviceAdapter);
        panel.addView(label("当前 USB 设备"), widthWrap());
        panel.addView(deviceSpinner, widthWrap());
        panel.addView(row(
                button("刷新 USB 设备", v -> refreshUsbDevices()),
                button("申请 USB 权限", v -> requestUsbPermission()),
                button("USB 相机数量", v -> readUsbCameraCount())
        ), widthWrap());
        panel.addView(row(
                button("执行单帧诊断", v -> runUsbDiagnostic()),
                button("关闭 USB Manager", v -> closeUsbManager())
        ), widthWrap());
        usbStatus = valueText("未初始化");
        panel.addView(usbStatus, widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildCameraSection() {
        LinearLayout panel = section("相机生命周期", "getCameras / getCamera / open / initialize / close");
        cameraSpinner = spinner();
        cameraAdapter = adapter();
        cameraSpinner.setAdapter(cameraAdapter);
        panel.addView(label("当前相机句柄"), widthWrap());
        panel.addView(cameraSpinner, widthWrap());
        cameraSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener() {
            @Override
            public void onItemSelected(int position) {
                if (position >= 0 && position < cameras.size()) {
                    currentCamera = cameras.get(position);
                    try {
                        cameraStatus.setText(propertiesText(currentCamera.getProperties()));
                    } catch (Throwable error) {
                        cameraStatus.setText(errorText(error));
                    }
                }
            }
        });
            panel.addView(row(
                button("刷新相机列表", v -> refreshSdkOverview()),
                button("按索引获取句柄", v -> getCameraByIndex()),
                button("读取属性", v -> readCameraProperties()),
                button("按 ID 获取句柄", v -> getCameraById())
        ), widthWrap());
        panel.addView(row(
                button("Open", v -> cameraOperation("open", PlayerOneCamera::open)),
                button("Initialize", v -> cameraOperation("initialize", PlayerOneCamera::initialize)),
                button("Close", v -> cameraOperation("close", PlayerOneCamera::close)),
                button("状态与计数", v -> readCameraState())
        ), widthWrap());
        cameraStatus = valueText("没有相机");
        panel.addView(cameraStatus, widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildConfigSection() {
        LinearLayout panel = section("类型化配置", "getConfigCount / getConfigAttributes / getConfig / setConfig");
        configSpinner = spinner();
        configAdapter = adapter();
        for (PoaConfig config : PoaConfig.values()) {
            configAdapter.add(config.name());
        }
        configSpinner.setAdapter(configAdapter);
        panel.addView(label("PoaConfig"), widthWrap());
        panel.addView(configSpinner, widthWrap());
        configValueInput = input("配置值，例如 100、1.5 或 true", "0");
        configAutoInput = new CheckBox(this);
        configAutoInput.setText("auto");
        configAutoInput.setTextColor(INK);
        panel.addView(row(configValueInput, configAutoInput), widthWrap());
        panel.addView(row(
                button("读取配置属性", v -> readConfigAttributes()),
                button("扫描全部配置", v -> scanAllConfigAttributes()),
                button("读取配置值", v -> readConfigValue()),
                button("写入配置值", v -> writeConfigValue())
        ), widthWrap());
        configStatus = valueText("请先选择相机并读取配置属性");
        panel.addView(configStatus, widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildImageSection() {
        LinearLayout panel = section("图像参数与 DirectByteBuffer", "ROI / bin / format / exposure / getImageData");
        roiXInput = input("x", "0");
        roiYInput = input("y", "0");
        roiWidthInput = input("width", "0");
        roiHeightInput = input("height", "0");
        binInput = input("bin", "1");
        timeoutInput = input("timeout ms", "5000");
        panel.addView(label("图像起点 x / y"), widthWrap());
        panel.addView(row(roiXInput, roiYInput), widthWrap());
        panel.addView(label("图像尺寸 width / height"), widthWrap());
        panel.addView(row(roiWidthInput, roiHeightInput), widthWrap());
        panel.addView(label("Bin / getImageData 超时"), widthWrap());
        panel.addView(row(binInput, timeoutInput), widthWrap());
        formatSpinner = spinner();
        formatAdapter = adapter();
        for (PoaImageFormat format : PoaImageFormat.values()) {
            formatAdapter.add(format.name());
        }
        formatSpinner.setAdapter(formatAdapter);
        panel.addView(label("PoaImageFormat"), widthWrap());
        panel.addView(formatSpinner, widthWrap());
        panel.addView(row(
                button("读取图像参数", v -> readImageSettings()),
                button("应用 ROI", v -> applyRoi()),
                button("应用 Bin", v -> applyBin()),
                button("应用格式", v -> applyImageFormat())
        ), widthWrap());
        panel.addView(row(
                button("单帧曝光并取图", v -> captureSingleFrame()),
                button("开始连续采集", v -> startContinuousExposure()),
                button("停止连续采集", v -> stopContinuousExposure()),
                button("图像状态", v -> readCameraState())
        ), widthWrap());
        imageStatus = valueText("未读取图像参数");
        panel.addView(imageStatus, widthWrap());
        imagePreview = new ImageView(this);
        imagePreview.setBackgroundColor(Color.BLACK);
        imagePreview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams previewParams = widthWrap();
        previewParams.height = dp(260);
        previewParams.setMargins(0, dp(8), 0, 0);
        panel.addView(imagePreview, previewParams);
        fullResolutionPreviewInput = new CheckBox(this);
        fullResolutionPreviewInput.setText("原始分辨率预览（大图会占用较多内存）");
        fullResolutionPreviewInput.setTextColor(INK);
        panel.addView(fullResolutionPreviewInput, widthWrap());
        panel.addView(button("清除图像预览", v -> imagePreview.setImageDrawable(null)), widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildSensorSection() {
        LinearLayout panel = section("Sensor Mode 与自定义 ID", "getSensorModeCount / getSensorModeInfo / setSensorMode / setUserCustomId");
        sensorSpinner = spinner();
        sensorAdapter = adapter();
        sensorSpinner.setAdapter(sensorAdapter);
        customIdInput = input("最多 16 bytes；留空可清除", "");
        panel.addView(row(
                button("刷新 Sensor Mode", v -> refreshSensorModes()),
                button("读取当前 Mode", v -> readCurrentSensorMode()),
                button("设置 Mode", v -> setSensorMode())
        ), widthWrap());
        panel.addView(sensorSpinner, widthWrap());
        panel.addView(row(customIdInput, button("写入自定义 ID", v -> setCustomId())), widthWrap());
        sensorStatus = valueText("未读取 Sensor Mode");
        panel.addView(sensorStatus, widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildGainSection() {
        LinearLayout panel = section("Gain / Offset", "兼容旧版 getGainOffset 和完整 getGainsAndOffsets");
        gainInput = input("Gain 数值", "0");
        panel.addView(row(
                gainInput,
                button("设置 Gain", v -> setGainValue()),
                button("读取当前 Gain", v -> readGainValue())
        ), widthWrap());
        gainStatus = valueText("未读取");
        panel.addView(gainStatus, widthWrap());
        panel.addView(button("读取 Gain / Offset 预设", v -> readGainOffset()), widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildCoolingSection() {
        LinearLayout panel = section("Cooler 制冷", "PoaConfig.COOLER / ConfigValue.ofBoolean");
        coolerInput = new CheckBox(this);
        coolerInput.setText("开启 Cooler");
        coolerInput.setTextColor(INK);
        panel.addView(row(
                coolerInput,
                button("设置 Cooler", v -> setCooler()),
                button("读取 Cooler 状态", v -> readCooler())
        ), widthWrap());
        coolerStatus = valueText("请先 Open、Initialize，并确认相机支持 Cooler");
        panel.addView(coolerStatus, widthWrap());
        content.addView(panel, widthWrap());
    }

    private void buildLogSection() {
        LinearLayout panel = section("运行日志", "所有异常显示错误码、类型和原始消息");
        logView = valueText("等待操作...");
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(12);
        panel.addView(logView, widthWrap());
        panel.addView(button("清空日志", v -> logView.setText("")), widthWrap());
        content.addView(panel, widthWrap());
    }

    private void createUsbManager() {
        try {
            usbManager = new PlayerOneUsbManager(this);
            setStatus(usbStatus, "USB Manager 已创建");
            appendLog("PlayerOneUsbManager 创建成功");
        } catch (Throwable error) {
            setStatus(usbStatus, errorText(error));
            appendLog("创建 USB Manager 失败: " + errorText(error));
        }
    }

    private void refreshUsbDevices() {
        if (usbManager == null) {
            appendLog("USB Manager 不可用");
            return;
        }
        try {
            usbDevices = usbManager.refreshDevices();
            replace(deviceAdapter, usbDeviceLabels(usbDevices));
            setStatus(usbStatus, "设备数: " + usbDevices.size() + "\n" + joinLines(usbDeviceLabels(usbDevices)));
            appendLog("refreshDevices 成功，返回 " + usbDevices.size() + " 个设备");
        } catch (Throwable error) {
            report("refreshDevices", error);
        }
    }

    private void requestUsbPermission() {
        if (usbManager == null || usbDevices.isEmpty()) {
            appendLog("没有可申请权限的 USB 设备");
            return;
        }
        final UsbCameraDevice device = usbDevices.get(selectedPosition(deviceSpinner));
        try {
            usbManager.requestPermission(device, (authorizedDevice, granted) -> {
                appendLog("requestPermission: " + deviceLabel(authorizedDevice) + ", granted=" + granted);
                if (granted) {
                    setStatus(usbStatus, "已授权: " + deviceLabel(authorizedDevice));
                    refreshSdkOverview();
                } else {
                    setStatus(usbStatus, "授权失败或用户拒绝: " + deviceLabel(authorizedDevice));
                }
            });
            appendLog("已发起 USB 权限请求");
        } catch (Throwable error) {
            report("requestPermission", error);
        }
    }

    private void readUsbCameraCount() {
        if (usbManager == null) {
            return;
        }
        try {
            int count = usbManager.getCameraCount();
            setStatus(usbStatus, "native camera count: " + count);
            appendLog("PlayerOneUsbManager.getCameraCount() = " + count);
        } catch (Throwable error) {
            report("getCameraCount", error);
        }
    }

    private void runUsbDiagnostic() {
        if (usbManager == null || usbDevices.isEmpty()) {
            appendLog("没有可执行诊断的 USB 设备");
            return;
        }
        final UsbCameraDevice device = usbDevices.get(selectedPosition(deviceSpinner));
        worker.execute(() -> {
            try {
                usbManager.runSingleFrameDiagnostic(device);
                postStatus(usbStatus, "单帧诊断成功: " + deviceLabel(device));
                appendLog("runSingleFrameDiagnostic 成功");
            } catch (Throwable error) {
                report("runSingleFrameDiagnostic", error);
            }
        });
    }

    private void closeUsbManager() {
        if (usbManager == null) {
            return;
        }
        try {
            usbManager.close();
            setStatus(usbStatus, "USB Manager 已关闭");
            appendLog("PlayerOneUsbManager.close() 成功");
        } catch (Throwable error) {
            report("close USB Manager", error);
        }
    }

    private void refreshSdkOverview() {
        worker.execute(() -> {
            try {
                int apiVersion = PlayerOneCameraSdk.getApiVersion();
                String sdkVersion = PlayerOneCameraSdk.getSdkVersion();
                int count = PlayerOneCameraSdk.getCameraCount();
                List<PlayerOneCamera> found = PlayerOneCameraSdk.getCameras();
                List<String> labels = new ArrayList<>();
                StringBuilder properties = new StringBuilder();
                for (int i = 0; i < count; i++) {
                    CameraProperties item = PlayerOneCameraSdk.getCameraProperties(i);
                    labels.add(cameraLabel(i, item));
                    properties.append("\n[index ").append(i).append("]\n").append(propertiesText(item));
                }
                postSdkResult(apiVersion, sdkVersion, count, found, labels, properties.toString());
            } catch (Throwable error) {
                report("refresh SDK overview", error);
            }
        });
    }

    private void postSdkResult(int apiVersion, String sdkVersion, int count,
                               List<PlayerOneCamera> found, List<String> labels, String properties) {
        mainHandler.post(() -> {
            cameras = found == null ? Collections.emptyList() : found;
            replace(cameraAdapter, labels);
            if (!cameras.isEmpty()) {
                currentCamera = cameras.get(0);
            }
            setStatus(sdkStatus, "API: " + apiVersion + "\nSDK: " + sdkVersion + "\nCamera count: " + count + properties);
            if (cameras.isEmpty()) {
                setStatus(cameraStatus, "没有相机");
            } else {
                setStatus(cameraStatus, "已获取 " + cameras.size() + " 个相机句柄\n请点击“读取属性”查看当前句柄详情");
            }
            appendLog("PlayerOneCameraSdk: version=" + sdkVersion + ", api=" + apiVersion + ", count=" + count);
        });
    }

    private void showAllErrors() {
        worker.execute(() -> {
            StringBuilder output = new StringBuilder("PoaError descriptions\n");
            for (PoaError error : PoaError.values()) {
                String description;
                try {
                    description = PlayerOneCameraSdk.getErrorDescription(error);
                } catch (Throwable ignored) {
                    description = error.getDescription();
                }
                output.append(error.getNativeValue()).append("  ").append(error.name())
                        .append("  ").append(description).append('\n');
            }
            postStatus(sdkStatus, output.toString());
            appendLog("getErrorDescription 已查询全部 " + PoaError.values().length + " 个错误码");
        });
    }

    private void readCameraProperties() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                CameraProperties properties = selected.getProperties();
                postStatus(cameraStatus, propertiesText(properties));
                appendLog("getProperties 成功，cameraId=" + selected.getCameraId());
            } catch (Throwable error) {
                report("getProperties", error);
            }
        });
    }

    private void getCameraByIndex() {
        final int index = selectedPosition(cameraSpinner);
        if (index < 0) {
            appendLog("请先刷新并选择相机索引");
            return;
        }
        worker.execute(() -> {
            try {
                currentCamera = PlayerOneCameraSdk.getCamera(index);
                postStatus(cameraStatus, "getCamera(" + index + ") 成功\n" + propertiesText(currentCamera.getProperties()));
                appendLog("getCamera(" + index + ") 成功");
            } catch (Throwable error) {
                report("getCamera(index)", error);
            }
        });
    }

    private void getCameraById() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                currentCamera = PlayerOneCameraSdk.getCameraById(selected.getCameraId());
                postStatus(cameraStatus, "getCameraById 成功\n" + propertiesText(currentCamera.getProperties()));
                appendLog("getCameraById(" + selected.getCameraId() + ") 成功");
            } catch (Throwable error) {
                report("getCameraById", error);
            }
        });
    }

    private void cameraOperation(String name, CameraOperation operation) {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                operation.run(selected);
                appendLog(name + " 成功, cameraId=" + selected.getCameraId());
                postStatus(cameraStatus, name + " 成功\nstate=" + safeState(selected));
            } catch (Throwable error) {
                report(name, error);
            }
        });
    }

    private void readCameraState() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                PoaCameraState state = selected.getState();
                boolean ready = selected.isImageReady();
                int dropped = selected.getDroppedImageCount();
                String status = "state=" + state + "\nimageReady=" + ready + "\ndroppedImages=" + dropped;
                postStatus(imageStatus, status);
                postStatus(cameraStatus, status);
                appendLog("getState/isImageReady/getDroppedImageCount 成功");
            } catch (Throwable error) {
                report("camera state", error);
            }
        });
    }

    private void readConfigAttributes() {
        final PlayerOneCamera selected = selectedCamera();
        final PoaConfig config = selectedConfig();
        if (selected == null || config == null) {
            return;
        }
        worker.execute(() -> {
            try {
                currentConfigAttributes = selected.getConfigAttributes(config);
                postStatus(configStatus, configAttributesText(currentConfigAttributes));
                appendLog("getConfigAttributes(PoaConfig) 成功: " + config.name());
            } catch (Throwable error) {
                report("getConfigAttributes", error);
            }
        });
    }

    private void scanAllConfigAttributes() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                int count = selected.getConfigCount();
                StringBuilder output = new StringBuilder("configCount=").append(count).append('\n');
                for (int i = 0; i < count; i++) {
                    ConfigAttributes attributes = selected.getConfigAttributes(i);
                    output.append('[').append(i).append("] ").append(configAttributesText(attributes)).append('\n');
                }
                postStatus(configStatus, output.toString());
                appendLog("getConfigCount + getConfigAttributes(index) 扫描完成: " + count);
            } catch (Throwable error) {
                report("scan config attributes", error);
            }
        });
    }

    private void readConfigValue() {
        final PlayerOneCamera selected = selectedCamera();
        final PoaConfig config = selectedConfig();
        if (selected == null || config == null) {
            return;
        }
        worker.execute(() -> {
            try {
                ConfigResult result = selected.getConfig(config);
                postStatus(configStatus, config.name() + "\nvalue=" + configValueText(result.getValue())
                        + "\nauto=" + result.isAuto());
                appendLog("getConfig 成功: " + config.name());
            } catch (Throwable error) {
                report("getConfig", error);
            }
        });
    }

    private void writeConfigValue() {
        final PlayerOneCamera selected = selectedCamera();
        final PoaConfig config = selectedConfig();
        if (selected == null || config == null) {
            return;
        }
        final String raw = configValueInput.getText().toString().trim();
        final boolean auto = configAutoInput.isChecked();
        worker.execute(() -> {
            try {
                ConfigAttributes attributes = currentConfigAttributes;
                if (attributes == null || attributes.getConfig() != config) {
                    attributes = selected.getConfigAttributes(config);
                }
                ConfigValue value = parseConfigValue(attributes.getValueType(), raw);
                selected.setConfig(config, value, auto);
                postStatus(configStatus, "写入成功\n" + config.name() + "=" + raw + "\nauto=" + auto);
                appendLog("setConfig 成功: " + config.name());
            } catch (Throwable error) {
                report("setConfig", error);
            }
        });
    }

    private void readImageSettings() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                ImagePosition position = selected.getImageStartPosition();
                ImageSize size = selected.getImageSize();
                int bin = selected.getImageBin();
                PoaImageFormat format = selected.getImageFormat();
                updateText(roiXInput, String.valueOf(position.getX()));
                updateText(roiYInput, String.valueOf(position.getY()));
                updateText(roiWidthInput, String.valueOf(size.getWidth()));
                updateText(roiHeightInput, String.valueOf(size.getHeight()));
                updateText(binInput, String.valueOf(bin));
                selectSpinner(formatSpinner, format.name());
                long bytes = size.requiredBytes(format);
                postStatus(imageStatus, "position=" + position.getX() + "," + position.getY()
                        + "\nsize=" + size.getWidth() + "x" + size.getHeight()
                        + "\nbin=" + bin + "\nformat=" + format + "\nrequiredBytes=" + bytes);
                appendLog("图像参数读取成功");
            } catch (Throwable error) {
                report("read image settings", error);
            }
        });
    }

    private void applyRoi() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final int x = integer(roiXInput);
        final int y = integer(roiYInput);
        final int width = integer(roiWidthInput);
        final int height = integer(roiHeightInput);
        worker.execute(() -> {
            try {
                selected.setImageStartPosition(x, y);
                selected.setImageSize(width, height);
                appendLog("setImageStartPosition/setImageSize 成功");
                readImageSettings();
            } catch (Throwable error) {
                report("apply ROI", error);
            }
        });
    }

    private void applyBin() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final int bin = integer(binInput);
        worker.execute(() -> {
            try {
                selected.setImageBin(bin);
                appendLog("setImageBin(" + bin + ") 成功");
                readImageSettings();
            } catch (Throwable error) {
                report("setImageBin", error);
            }
        });
    }

    private void applyImageFormat() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final PoaImageFormat format = selectedFormat();
        worker.execute(() -> {
            try {
                selected.setImageFormat(format);
                appendLog("setImageFormat(" + format + ") 成功");
                readImageSettings();
            } catch (Throwable error) {
                report("setImageFormat", error);
            }
        });
    }

    private void captureSingleFrame() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final int timeout = integer(timeoutInput);
        final boolean fullResolution = fullResolutionPreviewInput.isChecked();
        worker.execute(() -> {
            boolean started = false;
            try {
                ImageSize size = selected.getImageSize();
                PoaImageFormat format = selected.getImageFormat();
                PoaBayerPattern bayerPattern = selected.getProperties().getBayerPattern();
                long required = size.requiredBytes(format);
                if (required < 0 || required > Integer.MAX_VALUE) {
                    throw new IllegalArgumentException("image buffer is too large: " + required);
                }
                ByteBuffer image = ByteBuffer.allocateDirect((int) required);
                long startedAt = System.currentTimeMillis();
                selected.startExposure(true);
                started = true;
                while (!selected.isImageReady()) {
                    if (timeout >= 0 && System.currentTimeMillis() - startedAt > timeout) {
                        throw new IllegalStateException("imageReady timeout after " + timeout + " ms");
                    }
                    Thread.sleep(10L);
                }
                selected.getImageData(image, timeout);
                Bitmap preview = toPreviewBitmap(image, size, format, bayerPattern, fullResolution, openCvReady);
                mainHandler.post(() -> imagePreview.setImageBitmap(preview));
                postStatus(imageStatus, "单帧成功\nformat=" + format + "\nsize=" + size.getWidth() + "x" + size.getHeight()
                        + "\nbytes=" + required + "\nchecksum=" + checksum(image));
                appendLog("getImageData direct buffer 成功");
            } catch (Throwable error) {
                report("capture single frame", error);
            } finally {
                if (started) {
                    try {
                        selected.stopExposure();
                    } catch (Throwable error) {
                        report("stopExposure after capture", error);
                    }
                }
            }
        });
    }

    private static Bitmap toPreviewBitmap(ByteBuffer buffer, ImageSize size,
                                          PoaImageFormat format, PoaBayerPattern bayerPattern,
                                          boolean fullResolution, boolean useOpenCv) {
        if (useOpenCv && (format == PoaImageFormat.RAW8 || format == PoaImageFormat.MONO8)) {
            return toOpenCvBitmap(buffer, size, format, bayerPattern, fullResolution);
        }
        int sourceWidth = size.getWidth();
        int sourceHeight = size.getHeight();
        int longest = Math.max(sourceWidth, sourceHeight);
        int previewWidth = sourceWidth;
        int previewHeight = sourceHeight;
        if (!fullResolution && longest > 1280) {
            float scale = 1280f / longest;
            previewWidth = Math.max(1, Math.round(sourceWidth * scale));
            previewHeight = Math.max(1, Math.round(sourceHeight * scale));
        }
        long pixelCount = (long) previewWidth * previewHeight;
        if (pixelCount > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("preview is too large: " + previewWidth + "x" + previewHeight);
        }
        int[] pixels = new int[previewWidth * previewHeight];
        int bytesPerPixel = format.getBytesPerPixel();
        for (int y = 0; y < previewHeight; y++) {
            int sourceY = y * sourceHeight / previewHeight;
            for (int x = 0; x < previewWidth; x++) {
                int sourceX = x * sourceWidth / previewWidth;
                int sourceOffset = (sourceY * sourceWidth + sourceX) * bytesPerPixel;
                int red;
                int green;
                int blue;
                if (format == PoaImageFormat.RGB24) {
                    red = buffer.get(sourceOffset) & 0xff;
                    green = buffer.get(sourceOffset + 1) & 0xff;
                    blue = buffer.get(sourceOffset + 2) & 0xff;
                } else if (format == PoaImageFormat.RAW16) {
                    int low = buffer.get(sourceOffset) & 0xff;
                    int high = buffer.get(sourceOffset + 1) & 0xff;
                    int gray = ((high << 8) | low) >>> 8;
                    red = gray;
                    green = gray;
                    blue = gray;
                } else {
                    int gray = buffer.get(sourceOffset) & 0xff;
                    red = gray;
                    green = gray;
                    blue = gray;
                }
                pixels[y * previewWidth + x] = Color.rgb(red, green, blue);
            }
        }
        return Bitmap.createBitmap(pixels, previewWidth, previewHeight, Bitmap.Config.ARGB_8888);
    }

    private static Bitmap toOpenCvBitmap(ByteBuffer buffer, ImageSize size,
                                         PoaImageFormat format, PoaBayerPattern bayerPattern,
                                         boolean fullResolution) {
        int width = size.getWidth();
        int height = size.getHeight();
        long pixelCount = (long) width * height;
        if (pixelCount <= 0 || pixelCount > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("invalid image size: " + width + "x" + height);
        }

        byte[] raw = new byte[(int) pixelCount];
        ByteBuffer copy = buffer.duplicate();
        copy.clear();
        copy.get(raw);

        Mat source = new Mat(height, width, CvType.CV_8UC1);
        Mat rgba = new Mat();
        Mat resized = null;
        try {
            source.put(0, 0, raw);
            if (format == PoaImageFormat.MONO8 || bayerPattern == PoaBayerPattern.MONO) {
                Imgproc.cvtColor(source, rgba, Imgproc.COLOR_GRAY2RGBA);
            } else {
                int conversion;
                switch (bayerPattern) {
                    case RG:
                        conversion = Imgproc.COLOR_BayerRG2GRAY;
                        break;
                    case BG:
                        conversion = Imgproc.COLOR_BayerBG2RGBA;
                        break;
                    case GR:
                        conversion = Imgproc.COLOR_BayerGR2RGBA;
                        break;
                    case GB:
                        conversion = Imgproc.COLOR_BayerGB2RGBA;
                        break;
                    default:
                        conversion = Imgproc.COLOR_GRAY2RGBA;
                        break;
                }
                Imgproc.cvtColor(source, rgba, conversion);
            }

            Mat display = rgba;
            if (!fullResolution && Math.max(width, height) > 1280) {
                float scale = 1280f / Math.max(width, height);
                int previewWidth = Math.max(1, Math.round(width * scale));
                int previewHeight = Math.max(1, Math.round(height * scale));
                resized = new Mat();
                Imgproc.resize(source, resized, new Size(previewWidth, previewHeight), 0, 0, Imgproc.INTER_AREA);
                display = resized;
            }

            Bitmap bitmap = Bitmap.createBitmap(display.cols(), display.rows(), Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(display, bitmap);
            return bitmap;
        } finally {
            source.release();
            rgba.release();
            if (resized != null) {
                resized.release();
            }
        }
    }

    private void startContinuousExposure() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null || continuousRunning) {
            return;
        }
        final int timeout = integer(timeoutInput);
        final boolean fullResolution = fullResolutionPreviewInput.isChecked();
        continuousRunning = true;
        worker.execute(() -> {
            boolean started = false;
            long frameCount = 0;
            try {
                ImageSize size = selected.getImageSize();
                PoaImageFormat format = selected.getImageFormat();
                PoaBayerPattern bayerPattern = selected.getProperties().getBayerPattern();
                long required = size.requiredBytes(format);
                if (required < 0 || required > Integer.MAX_VALUE) {
                    throw new IllegalArgumentException("image buffer is too large: " + required);
                }
                ByteBuffer image = ByteBuffer.allocateDirect((int) required);
                selected.startExposure(false);
                started = true;
                postStatus(imageStatus, "连续采集已启动\nformat=" + format
                        + "\nsize=" + size.getWidth() + "x" + size.getHeight());
                appendLog("startExposure(false) 成功");
                while (continuousRunning) {
                    if (!selected.isImageReady()) {
                        Thread.sleep(10L);
                        continue;
                    }
                    selected.getImageData(image, timeout);
                    frameCount++;
                    Bitmap preview = toPreviewBitmap(image, size, format, bayerPattern, fullResolution, openCvReady);
                    final long displayedFrame = frameCount;
                    mainHandler.post(() -> imagePreview.setImageBitmap(preview));
                    postStatus(imageStatus, "连续采集中\nframe=" + displayedFrame
                            + "\nformat=" + format + "\nsize=" + size.getWidth() + "x" + size.getHeight()
                            + "\nchecksum=" + checksum(image));
                }
            } catch (Throwable error) {
                report("continuous capture", error);
            } finally {
                continuousRunning = false;
                if (started) {
                    try {
                        selected.stopExposure();
                        appendLog("连续采集已停止，共获取 " + frameCount + " 帧");
                        postStatus(imageStatus, "连续采集已停止\nframes=" + frameCount);
                    } catch (Throwable error) {
                        report("stopExposure after continuous capture", error);
                    }
                }
            }
        });
    }

    private void stopContinuousExposure() {
        if (!continuousRunning) {
            appendLog("当前没有正在运行的连续采集");
            return;
        }
        continuousRunning = false;
        appendLog("已请求停止连续采集");
    }

    private void refreshSensorModes() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                int count = selected.getSensorModeCount();
                List<SensorModeInfo> modes = new ArrayList<>();
                List<String> labels = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                    SensorModeInfo info = selected.getSensorModeInfo(i);
                    modes.add(info);
                    labels.add(i + ": " + info.getName() + " - " + info.getDescription());
                }
                sensorModes = modes;
                mainHandler.post(() -> {
                    replace(sensorAdapter, labels);
                    setStatus(sensorStatus, "sensorModeCount=" + count + "\n" + joinLines(labels));
                });
                appendLog("Sensor Mode 扫描完成: " + count);
            } catch (Throwable error) {
                report("refresh Sensor Mode", error);
            }
        });
    }

    private void readCurrentSensorMode() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                int mode = selected.getSensorMode();
                postStatus(sensorStatus, "当前 sensorMode=" + mode);
                appendLog("getSensorMode() = " + mode);
            } catch (Throwable error) {
                report("getSensorMode", error);
            }
        });
    }

    private void setSensorMode() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final int mode = selectedPosition(sensorSpinner);
        worker.execute(() -> {
            try {
                selected.setSensorMode(mode);
                postStatus(sensorStatus, "setSensorMode(" + mode + ") 成功，当前=" + selected.getSensorMode());
                appendLog("setSensorMode 成功: " + mode);
            } catch (Throwable error) {
                report("setSensorMode", error);
            }
        });
    }

    private void setCustomId() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final String id = customIdInput.getText().toString();
        worker.execute(() -> {
            try {
                selected.setUserCustomId(id);
                postStatus(cameraStatus, "setUserCustomId 成功: " + (id.isEmpty() ? "<cleared>" : id));
                appendLog("setUserCustomId 成功");
            } catch (Throwable error) {
                report("setUserCustomId", error);
            }
        });
    }

    private void readGainOffset() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                LegacyGainOffset legacy = selected.getGainOffset();
                GainOffsetPreset preset = selected.getGainsAndOffsets();
                String output = "LegacyGainOffset\n" + legacyText(legacy)
                        + "\nGainOffsetPreset\n" + presetText(preset);
                postStatus(gainStatus, output);
                appendLog("getGainOffset/getGainsAndOffsets 成功");
            } catch (Throwable error) {
                report("read gain offset", error);
            }
        });
    }

    private void setGainValue() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final long gain;
        try {
            gain = Long.parseLong(gainInput.getText().toString().trim());
        } catch (NumberFormatException error) {
            setStatus(gainStatus, "Gain 必须是整数");
            return;
        }
        worker.execute(() -> {
            try {
                ConfigAttributes attributes = selected.getConfigAttributes(PoaConfig.GAIN);
                if (attributes.getValueType() != PoaValueType.INTEGER) {
                    throw new IllegalStateException("GAIN 类型不是 INTEGER: " + attributes.getValueType());
                }
                long minimum = attributes.getMinimum().asInteger();
                long maximum = attributes.getMaximum().asInteger();
                if (gain < minimum || gain > maximum) {
                    throw new IllegalArgumentException("Gain 超出范围: " + minimum + " - " + maximum);
                }
                selected.setConfig(PoaConfig.GAIN, ConfigValue.ofInteger(gain), false);
                ConfigResult result = selected.getConfig(PoaConfig.GAIN);
                postStatus(gainStatus, "Gain 设置成功\nvalue=" + configValueText(result.getValue())
                        + "\nauto=" + result.isAuto() + "\nrange=" + minimum + " - " + maximum);
                appendLog("setConfig(GAIN) 成功: " + gain);
            } catch (Throwable error) {
                report("set Gain", error);
            }
        });
    }

    private void readGainValue() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                ConfigResult result = selected.getConfig(PoaConfig.GAIN);
                updateText(gainInput, configValueText(result.getValue()));
                postStatus(gainStatus, "当前 Gain=" + configValueText(result.getValue())
                        + "\nauto=" + result.isAuto());
                appendLog("getConfig(GAIN) 成功");
            } catch (Throwable error) {
                report("read Gain", error);
            }
        });
    }

    private void setCooler() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        final boolean enabled = coolerInput.isChecked();
        worker.execute(() -> {
            try {
                ConfigAttributes attributes = selected.getConfigAttributes(PoaConfig.COOLER);
                if (attributes.getValueType() != PoaValueType.BOOLEAN) {
                    throw new IllegalStateException("COOLER 类型不是 BOOLEAN: " + attributes.getValueType());
                }
                selected.setConfig(PoaConfig.COOLER, ConfigValue.ofBoolean(enabled), false);
                ConfigResult result = selected.getConfig(PoaConfig.COOLER);
                postStatus(coolerStatus, "Cooler 设置成功\nenabled=" + configValueText(result.getValue())
                        + "\nauto=" + result.isAuto());
                appendLog("setConfig(COOLER) 成功: " + enabled);
            } catch (Throwable error) {
                report("set Cooler", error);
            }
        });
    }

    private void readCooler() {
        final PlayerOneCamera selected = selectedCamera();
        if (selected == null) {
            return;
        }
        worker.execute(() -> {
            try {
                ConfigResult result = selected.getConfig(PoaConfig.COOLER);
                if (result.getValue().getType() != PoaValueType.BOOLEAN) {
                    throw new IllegalStateException("COOLER 返回值不是 BOOLEAN");
                }
                boolean enabled = result.getValue().asBoolean();
                mainHandler.post(() -> coolerInput.setChecked(enabled));
                postStatus(coolerStatus, "当前 Cooler=" + enabled + "\nauto=" + result.isAuto());
                appendLog("getConfig(COOLER) 成功");
            } catch (Throwable error) {
                report("read Cooler", error);
            }
        });
    }

    private PlayerOneCamera selectedCamera() {
        int position = selectedPosition(cameraSpinner);
        if (position >= 0 && position < cameras.size()) {
            currentCamera = cameras.get(position);
        }
        if (currentCamera == null) {
            appendLog("请先刷新并选择相机");
        }
        return currentCamera;
    }

    private PoaConfig selectedConfig() {
        int position = selectedPosition(configSpinner);
        PoaConfig[] values = PoaConfig.values();
        return position >= 0 && position < values.length ? values[position] : null;
    }

    private PoaImageFormat selectedFormat() {
        int position = selectedPosition(formatSpinner);
        PoaImageFormat[] values = PoaImageFormat.values();
        return position >= 0 && position < values.length ? values[position] : PoaImageFormat.RAW8;
    }

    private static ConfigValue parseConfigValue(PoaValueType type, String raw) {
        switch (type) {
            case INTEGER:
                return ConfigValue.ofInteger(Long.parseLong(raw));
            case FLOAT:
                return ConfigValue.ofFloat(Double.parseDouble(raw));
            case BOOLEAN:
                if (!"true".equalsIgnoreCase(raw) && !"false".equalsIgnoreCase(raw)) {
                    throw new IllegalArgumentException("boolean value must be true or false");
                }
                return ConfigValue.ofBoolean(Boolean.parseBoolean(raw));
            default:
                throw new IllegalArgumentException("unsupported config type: " + type);
        }
    }

    private static String configValueText(ConfigValue value) {
        if (value == null) {
            return "null";
        }
        switch (value.getType()) {
            case INTEGER:
                return String.valueOf(value.asInteger());
            case FLOAT:
                return String.valueOf(value.asFloat());
            case BOOLEAN:
                return String.valueOf(value.asBoolean());
            default:
                return value.getType().name();
        }
    }

    private static String configAttributesText(ConfigAttributes attributes) {
        if (attributes == null) {
            return "null attributes";
        }
        return "config=" + attributes.getConfig()
                + "\nname=" + attributes.getName()
                + "\ndescription=" + attributes.getDescription()
                + "\ntype=" + attributes.getValueType()
                + "\nreadable=" + attributes.isReadable()
                + " writable=" + attributes.isWritable()
                + " auto=" + attributes.supportsAuto()
                + "\nmin=" + configValueText(attributes.getMinimum())
                + " max=" + configValueText(attributes.getMaximum())
                + " default=" + configValueText(attributes.getDefaultValue());
    }

    private static String propertiesText(CameraProperties p) {
        if (p == null) {
            return "null properties";
        }
        return "model=" + p.getCameraModelName()
                + "\ncustomId=" + p.getUserCustomId()
                + "\ncameraId=" + p.getCameraId() + " productId=" + p.getProductId()
                + "\nsensor=" + p.getSensorModelName() + " serial=" + p.getSerialNumber()
                + "\nsize=" + p.getMaxWidth() + "x" + p.getMaxHeight() + " bitDepth=" + p.getBitDepth()
                + "\npixel=" + p.getPixelSizeMicrometers() + "um color=" + p.isColorCamera()
                + "\nbayer=" + p.getBayerPattern() + " bins=" + p.getBins()
                + "\nformats=" + p.getImageFormats()
                + "\nST4=" + p.hasSt4Port() + " cooler=" + p.hasCooler() + " USB3=" + p.isUsb3Speed()
                + " hardwareBin=" + p.supportsHardwareBin()
                + "\nlocalPath=" + p.getLocalPath();
    }

    private static String legacyText(LegacyGainOffset value) {
        return "offsetHDR=" + value.getOffsetHighestDynamicRange()
                + " offsetUnity=" + value.getOffsetUnityGain()
                + " gainLowestNoise=" + value.getGainLowestReadNoise()
                + " offsetLowestNoise=" + value.getOffsetLowestReadNoise()
                + " highConversionGain=" + value.getHighConversionGain();
    }

    private static String presetText(GainOffsetPreset value) {
        return "gainHDR=" + value.getGainHighestDynamicRange()
                + " gainHCG=" + value.getHighConversionGain()
                + " gainUnity=" + value.getUnityGain()
                + " gainLowestNoise=" + value.getGainLowestReadNoise()
                + " offsetHDR=" + value.getOffsetHighestDynamicRange()
                + " offsetHCG=" + value.getOffsetHighConversionGain()
                + " offsetUnity=" + value.getOffsetUnityGain()
                + " offsetLowestNoise=" + value.getOffsetLowestReadNoise();
    }

    private static String checksum(ByteBuffer buffer) {
        long sum = 0;
        int sample = Math.min(buffer.capacity(), 4096);
        for (int i = 0; i < sample; i++) {
            sum = (sum * 31 + (buffer.get(i) & 0xff)) & 0xffffffffL;
        }
        return String.format(Locale.US, "0x%08x (first %d bytes)", sum, sample);
    }

    private static String safeState(PlayerOneCamera camera) {
        try {
            return String.valueOf(camera.getState());
        } catch (Throwable error) {
            return errorText(error);
        }
    }

    private static String cameraLabel(int index, CameraProperties p) {
        return index + ": " + p.getCameraModelName() + " [id=" + p.getCameraId() + "] " + p.getSerialNumber();
    }

    private static String deviceLabel(UsbCameraDevice device) {
        return device.getDeviceName() + " VID=0x" + Integer.toHexString(device.getVendorId())
                + " PID=0x" + Integer.toHexString(device.getProductId())
                + " reg=" + device.getRegistrationId() + " authorized=" + device.isAuthorized();
    }

    private static List<String> usbDeviceLabels(List<UsbCameraDevice> devices) {
        List<String> labels = new ArrayList<>();
        for (UsbCameraDevice device : devices) {
            labels.add(deviceLabel(device));
        }
        return labels;
    }

    private static String joinLines(List<String> values) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            result.append(value).append('\n');
        }
        return result.toString();
    }

    private void report(String operation, Throwable error) {
        String message = operation + " 失败: " + errorText(error);
        appendLog(message);
        if (operation.contains("image")) {
            postStatus(imageStatus, message);
        } else if (operation.contains("config")) {
            postStatus(configStatus, message);
        } else if (operation.contains("Sensor")) {
            postStatus(sensorStatus, message);
        } else if (operation.contains("gain")) {
            postStatus(gainStatus, message);
        } else if (operation.contains("USB") || operation.contains("Permission") || operation.contains("diagnostic")) {
            postStatus(usbStatus, message);
        } else {
            postStatus(cameraStatus, message);
        }
    }

    private static String errorText(Throwable error) {
        if (error instanceof PoaException) {
            PoaException poa = (PoaException) error;
            return "PoaException code=" + poa.getErrorCode() + " error=" + poa.getError()
                    + " message=" + poa.getMessage();
        }
        return error.getClass().getSimpleName() + ": " + error.getMessage();
    }

    private void appendLog(String message) {
        mainHandler.post(() -> {
            if (logView == null) {
                return;
            }
            String old = logView.getText().toString();
            String next = old + (old.isEmpty() ? "" : "\n") + message;
            if (next.length() > 12000) {
                next = next.substring(next.length() - 12000);
            }
            logView.setText(next);
        });
    }

    private void postStatus(TextView view, String value) {
        mainHandler.post(() -> setStatus(view, value));
    }

    private static void setStatus(TextView view, String value) {
        if (view != null) {
            view.setText(value == null ? "null" : value);
        }
    }

    private void updateText(EditText input, String value) {
        mainHandler.post(() -> input.setText(value));
    }

    private static int integer(EditText input) {
        return Integer.parseInt(input.getText().toString().trim());
    }

    private static int selectedPosition(Spinner spinner) {
        return spinner == null ? -1 : spinner.getSelectedItemPosition();
    }

    private static void selectSpinner(Spinner spinner, String value) {
        if (spinner == null || spinner.getAdapter() == null) {
            return;
        }
        for (int i = 0; i < spinner.getAdapter().getCount(); i++) {
            if (value.equals(spinner.getAdapter().getItem(i))) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private static void replace(ArrayAdapter<String> adapter, List<String> values) {
        if (adapter == null) {
            return;
        }
        adapter.clear();
        adapter.addAll(values);
        adapter.notifyDataSetChanged();
    }

    private ArrayAdapter<String> adapter() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private Spinner spinner() {
        Spinner result = new Spinner(this);
        result.setPadding(dp(4), 0, dp(4), 0);
        return result;
    }

    private EditText input(String hint, String value) {
        EditText result = new EditText(this);
        result.setSingleLine(true);
        result.setHint(hint);
        result.setText(value);
        result.setTextColor(INK);
        result.setHintTextColor(MUTED);
        result.setTextSize(14);
        result.setPadding(dp(8), 0, dp(8), 0);
        result.setBackgroundColor(Color.WHITE);
        return result;
    }

    private Button button(String title, View.OnClickListener listener) {
        Button result = new Button(this);
        result.setText(title);
        result.setTextSize(12);
        result.setTextColor(BLUE);
        result.setAllCaps(false);
        result.setOnClickListener(listener);
        return result;
    }

    private TextView label(String value) {
        TextView result = text(value, 12, MUTED, true);
        result.setPadding(0, dp(8), 0, dp(2));
        return result;
    }

    private TextView valueText(String value) {
        TextView result = text(value, 13, INK, false);
        result.setPadding(dp(10), dp(8), dp(10), dp(8));
        result.setBackgroundColor(Color.WHITE);
        return result;
    }

    private LinearLayout section(String title, String subtitle) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        panel.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, dp(8), 0, 0);

        TextView heading = text(title, 18, INK, true);
        panel.addView(heading, widthWrap());
        TextView detail = text(subtitle, 12, MUTED, false);
        detail.setPadding(0, dp(2), 0, dp(6));
        panel.addView(detail, widthWrap());
        panel.setTag(params);
        return panel;
    }

    private LinearLayout row(View... views) {
        LinearLayout result = new LinearLayout(this);
        result.setOrientation(LinearLayout.HORIZONTAL);
        result.setGravity(Gravity.CENTER_VERTICAL);
        for (View view : views) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1f);
            params.setMargins(dp(2), dp(2), dp(2), dp(2));
            result.addView(view, params);
        }
        return result;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView result = new TextView(this);
        result.setText(value);
        result.setTextSize(size);
        result.setTextColor(color);
        result.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return result;
    }

    private LinearLayout.LayoutParams widthWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        try {
            if (currentCamera != null) {
                currentCamera.close();
            }
        } catch (Throwable error) {
            appendLog("销毁相机失败: " + errorText(error));
        }
        if (usbManager != null) {
            try {
                usbManager.close();
            } catch (Throwable error) {
                appendLog("销毁 USB Manager 失败: " + errorText(error));
            }
        }
        worker.shutdownNow();
        super.onDestroy();
    }

    private interface CameraOperation {
        void run(PlayerOneCamera camera);
    }

    private abstract static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) {
        }

        public abstract void onItemSelected(int position);

        @Override
        public final void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            onItemSelected(position);
        }
    }
}
